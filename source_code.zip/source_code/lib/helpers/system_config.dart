

import 'package:active_ecommerce_flutter/data_model/currency_response.dart';

class SystemConfig{
  static CurrencyInfo? defaultCurrency;
  static CurrencyInfo? systemCurrency;
}