class OtherConfig {
  static const bool USE_PUSH_NOTIFICATION = false;
  static const bool USE_GOOGLE_MAP = false;
  static const String GOOGLE_MAP_API_KEY = "";
}
