// To parse this JSON data, do
//
//     final offlineWalletRechargeResponse = offlineWalletRechargeResponseFromJson(jsonString);
import 'package:active_ecommerce_flutter/app_config.dart';
import 'package:active_ecommerce_flutter/custom/device_info.dart';
import 'package:active_ecommerce_flutter/data_model/message_response.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:one_context/one_context.dart';
import 'dart:convert';

OfflineWalletRechargeResponse offlineWalletRechargeResponseFromJson(
        String str) =>
    OfflineWalletRechargeResponse.fromJson(json.decode(str));

String offlineWalletRechargeResponseToJson(
        OfflineWalletRechargeResponse data) =>
    json.encode(data.toJson());

class OfflineWalletRechargeResponse {
  OfflineWalletRechargeResponse({
    this.result,
    this.message,
  });

  bool result;
  String message;

  factory OfflineWalletRechargeResponse.fromJson(Map<String, dynamic> json) =>
      OfflineWalletRechargeResponse(
        result: json["result"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "result": result,
        "message": message,
      };
}
