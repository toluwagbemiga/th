

class OthersHelper{
  setPickupPoint(){
    
  }
}